<?php
 
$dbname = 'crud_php' ;    
$host = 'localhost' ;    
$dbuser =  'root';    
$dbpass = '';    
 
try{
    $db = new PDO("mysql:dbname=" .$dbname.";host=".$host.";port=3307", $dbuser, $dbpass);
} catch(PDOException $e){
    echo "Erro na Conexão" . $e->getMessage();
    exit();
}
 
 
define('BASE URL', 'http://localhost/crud_php/')
 
?>